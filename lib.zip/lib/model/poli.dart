class Poli {
  String? id;
  String namaPoli;

  Poli({this.id, required this.namaPoli});
}
