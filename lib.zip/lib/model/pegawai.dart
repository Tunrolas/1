class Pegawai {
  String? id;
  String nama;
  String nip;
  String ttl;
  String telp;
  String email;
  String password;

  Pegawai(
      {this.id,
      required this.nama,
      required this.nip,
      required this.ttl,
      required this.telp,
      required this.email,
      required this.password});
}
