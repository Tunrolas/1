class Pasien {
  String? id;
  String nama;
  String nomor_rm;
  String ttl;
  String telp;
  String alamat;

  Pasien(
      {this.id,
      required this.nama,
      required this.nomor_rm,
      required this.ttl,
      required this.telp,
      required this.alamat});
}
